import pygame
from elements.configs import BASE_GROUND_Y, BASE_GROUND_X, GAME_SPEED


class Hunter:
    hunter_walk1 = pygame.image.load("images/hunter_walk1.png").convert_alpha()
    hunter_walk2 = pygame.image.load("images/hunter_walk2.png").convert_alpha()
    hunter_dead = pygame.image.load("images/hunter_dead.png").convert_alpha()
    hunter_jump = pygame.image.load("images/hunter_jump.png").convert_alpha()
    hunter_shoot = pygame.image.load("images/hunter_shoot.png").convert_alpha()

    walk_img1 = pygame.transform.scale(hunter_walk1, (90, 90))
    walk_img2 = pygame.transform.scale(hunter_walk2, (90, 90))
    dead_img = pygame.transform.scale(hunter_dead, (90, 90))

    jump_img = pygame.transform.scale(hunter_jump, (90, 90))
    shoot_img = pygame.transform.scale(hunter_shoot, (90, 90))

    hunter_img_list = [walk_img1, walk_img2]

    def __init__(self):
        self.image_list = self.hunter_img_list
        self.is_alive = True
        self.jump_velocity = 0
        self.gravity = 1
        self.index = 0
        self.is_jumping = False
        self.is_shooting = False
        self.shoot_time = 0
        self.game_speed = GAME_SPEED
        self.rect = self.image_list[0].get_rect()
        self.rect.x = BASE_GROUND_X
        self.rect.y = BASE_GROUND_Y

    def jump(self):
        if not self.is_jumping:
            self.jump_velocity = -20
            self.is_jumping = True
            
            

    def shoot(self):
        if not self.is_shooting:
            self.shoot_time = 15
            self.is_shooting = True

    def update(self):
        if self.is_jumping:
            self.rect.y += self.jump_velocity
            self.jump_velocity += self.gravity

            if self.jump_velocity < 0:
                self.rect.x += 3
            else:
                if not self.is_shooting:
                    self.game_speed = GAME_SPEED

            if self.rect.y >= BASE_GROUND_Y:
                self.rect.y = BASE_GROUND_Y
                self.is_jumping = False
                self.jump_velocity = 0

        if self.rect.x > BASE_GROUND_X:
            self.rect.x -= 1

        if self.is_shooting:
            self.shoot_time -= 1

            if self.shoot_time > 0:
                self.game_speed = 1
            else:
                self.shoot_time = 0
                self.game_speed = GAME_SPEED
                self.is_shooting = False

    def draw(self, display_surface):
        if not self.is_alive:
            image = self.dead_img
        elif self.is_shooting:
            image = self.shoot_img
        elif self.is_jumping:
            image = self.jump_img
        else:
            self.index += 1

            if self.index >= 9:
                self.index = 0

            image = self.image_list[self.index // 5]

        display_surface.blit(image, self.rect)
        
      


