import pygame

from elements.configs import WINDOW_WIDTH,WINDOW_HEIGHT,GAME_SPEED,OBSTACLES, BASE_GROUND_Y,BASE_SKY_Y
from abc import ABC, abstractmethod

class Obstacle(ABC):
    def __init__(self, image_list, element, speed):
        self.image_list = image_list
        self.index = 0
        self.speed = speed
        self.rect = self.image_list[self.index].get_rect()
        self.rect.x = WINDOW_WIDTH
        self.element = element

    @abstractmethod
    def handle_element(self, *args, **kwargs):
        pass

    def update(self, display_surface):
        self.rect.x -= self.speed
        if self.rect.x < 0:
            # OBSTACLES starts as an ampty list that will receive the obstacle objects
            # Once the obstacle reaches out of the window, it is poped out of the list
            OBSTACLES.remove(self)

        self.element.handle_element()
        if self.element.to_draw:
            self.draw(display_surface)
    
    

        
    
    def draw(self, display_surface):
        if len(self.image_list) == 0:
            return 
        
        if len(self.image_list) > 1:
            if self.index >= 9:
                self.index = 0
            display_surface.blit(self.image_list[self.index//5], self.rect)
            self.index += 1
        elif len(self.image_list) == 1:
            display_surface.blit(self.image_list[0], self.rect)
        




class Rock(Obstacle):
    png = pygame.image.load("images/hunter_shoot.png").convert_alpha()
    rock_img_list = [pygame.transform.scale(png, (10, 10))]

    def __init__(self):
        self.speed = GAME_SPEED
        self.img_list = self.rock_img_list

        super().__init__(image_list=self.img_list, element=self, speed=self.speed)

        self.rect.y = BASE_GROUND_Y
        self.to_draw = True



    def handle_element(self):
        pass


class Sun(Obstacle):
    png = pygame.image.load("images/hunter_shoot.png").convert_alpha()
    sun_img_list = [pygame.transform.scale(png, (10, 10))]

    def __init__(self):
        self.img_list = self.sun_img_list
        self.speed = 0.03

        super().__init__(image_list=self.img_list, element=self, speed=self.speed)

        self.rect.y = BASE_SKY_Y - 50
        self.to_draw = True
    
    def handle_element(self):
        pass

    def update(self, display_surface):
        if not self.rect.x < 0:
            self.draw(display_surface)
        self.rect.x -= self.speed

class Bird(Obstacle):
    png = pygame.image.load("images/hunter_shoot.png").convert_alpha()
    bird_img_list = [pygame.transform.scale(png, (10, 10))]

    def __init__(self):
        self.img_list = self.bird_img_list
        self.speed = GAME_SPEED

        super().__init__(image_list=self.img_list, element=self, speed=self.speed)

        self.rect.y = BASE_SKY_Y
        self.to_draw = True
        

    def handle_element(self):
        if self.rect.y >= (WINDOW_HEIGHT - 200):
            self.rect.y += 1
        elif self.rect.y <= (WINDOW_HEIGHT - 50):
            self.rect.y -= 1
        else:
            self.rect.y = BASE_SKY_Y  


class Wolf(Obstacle):
    wolf_run1 = pygame.image.load("images/wolf_run1.png").convert_alpha()
    wolf_run2 = pygame.image.load("images/wolf_run2.png").convert_alpha()
    wolf_dead = pygame.image.load("images/hunter_shoot.png").convert_alpha()
    wolf_run_p1 = pygame.transform.scale(wolf_run1, (60, 60))
    wolf_run_p2 = pygame.transform.scale(wolf_run2, (60, 60))
    wolf_dead_list = [pygame.transform.scale(wolf_dead, (60, 60))]
    WOLF_RUN = [wolf_run_p1, wolf_run_p2]
    dead_time = 5
    
    def __init__(self):
        self.img_list = self.WOLF_RUN
        self.speed = GAME_SPEED + 0.9

        super().__init__(image_list=self.img_list, element=self, speed=self.speed)

        self.rect.y = BASE_GROUND_Y
        self.was_shot = False
        self.to_draw = True

    def handle_element(self, action = False):
        if self.was_shot or action:
            self.was_shot = True
            self.image_list = self.wolf_dead_list
            self.speed = 0






