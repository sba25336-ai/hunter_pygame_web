import pygame
from abc import ABC, abstractmethod
from elements.configs import (
    WINDOW_WIDTH,
    WINDOW_HEIGHT,
    GAME_SPEED,
    OBSTACLES,
    BASE_GROUND_Y,
    BASE_SKY_Y,
)


class Obstacle(ABC):
    def __init__(self, image_list, element, speed):
        self.image_list = image_list
        self.index = 0
        self.speed = speed
        self.element = element
        self.to_draw = True

        self.rect = self.image_list[0].get_rect()
        self.rect.x = WINDOW_WIDTH

    @abstractmethod
    def handle_element(self, *args, **kwargs):
        pass

    def update(self, display_surface):
        self.rect.x -= self.speed

        if self.rect.right < 0:
            if self in OBSTACLES:
                OBSTACLES.remove(self)
            return

        self.handle_element()

        if self.to_draw:
            self.draw(display_surface)

    def draw(self, display_surface):
        if len(self.image_list) == 0:
            return

        if len(self.image_list) > 1:
            if self.index >= len(self.image_list) * 5:
                self.index = 0

            display_surface.blit(self.image_list[self.index // 5], self.rect)
            self.index += 1

        else:
            display_surface.blit(self.image_list[0], self.rect)


class Rock(Obstacle):
    png = pygame.image.load("images/rock.png").convert_alpha()
    rock_img_list = [pygame.transform.scale(png, (50, 50))]

    def __init__(self):
        self.speed = GAME_SPEED + 1
        self.img_list = self.rock_img_list

        super().__init__(image_list=self.img_list, element=self, speed=self.speed)

        self.rect.y = BASE_GROUND_Y + 40

    def handle_element(self, *args, **kwargs):
        pass


# class Sun(Obstacle):
#     png = pygame.image.load("images/sun.png").convert_alpha()
#     sun_img_list = [pygame.transform.scale(png, (10, 10))]

#     def __init__(self):
#         self.img_list = self.sun_img_list
#         self.speed = 0.03

#         super().__init__(image_list=self.img_list, element=self, speed=self.speed)

#         self.rect.y = BASE_SKY_Y - 50

#     def handle_element(self, *args, **kwargs):
#         pass

#     def update(self, display_surface):
#         if self.rect.right > 0:
#             self.draw(display_surface)

#         self.rect.x -= self.speed


class Bird(Obstacle):
    png1 = pygame.image.load("images/bird1.png").convert_alpha()
    png2 = pygame.image.load("images/bird2.png").convert_alpha()
    bird1 = pygame.transform.scale(png1, (30, 30))
    bird2 = pygame.transform.scale(png2, (30, 30))
    bird_img_list = [bird1, bird2]

    def __init__(self):
        self.img_list = self.bird_img_list
        self.speed = GAME_SPEED
        self.y_direction = 1

        super().__init__(image_list=self.img_list, element=self, speed=self.speed)

        self.rect.y = BASE_SKY_Y

    def handle_element(self, *args, **kwargs):
        self.rect.y += self.y_direction

        if self.rect.y <= BASE_SKY_Y:
            self.y_direction = 1
        elif self.rect.y >= WINDOW_HEIGHT - 350:
            self.y_direction = -1


class Wolf(Obstacle):
    wolf_run1 = pygame.image.load("images/wolf_run1.png").convert_alpha()
    wolf_run2 = pygame.image.load("images/wolf_run2.png").convert_alpha()
    wolf_dead = pygame.image.load("images/wolf_dead.png").convert_alpha()

    wolf_run_p1 = pygame.transform.scale(wolf_run1, (70, 70))
    wolf_run_p2 = pygame.transform.scale(wolf_run2, (70, 70))
    wolf_dead_list = [pygame.transform.scale(wolf_dead, (70, 70))]

    WOLF_RUN = [wolf_run_p1, wolf_run_p2]

    def __init__(self):
        self.img_list = self.WOLF_RUN
        self.speed = GAME_SPEED + 0.9

        super().__init__(image_list=self.img_list, element=self, speed=self.speed)

        self.rect.y = BASE_GROUND_Y + 10
        self.was_shot = False
        self.dead_time = 30

    def handle_element(self, action=False):
        if action:
            self.was_shot = True
            self.image_list = self.wolf_dead_list
            self.speed = 0

        if self.was_shot:
            self.dead_time -= 1

            if self.dead_time <= 0:
                if self in OBSTACLES:
                    OBSTACLES.remove(self)