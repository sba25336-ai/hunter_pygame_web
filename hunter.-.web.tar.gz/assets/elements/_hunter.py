import pygame
from elements.configs import BASE_GROUND_Y, GAME_SPEED


class Hunter:
    hunter_walk = pygame.image.load("images/hunter_walk.png").convert_alpha()
    hunter_jump = pygame.image.load("images/hunter_jump.png").convert_alpha()
    hunter_shoot = pygame.image.load("images/hunter_shoot.png").convert_alpha()

    walk_img = pygame.transform.scale(hunter_walk, (90, 90))
    jump_img = pygame.transform.scale(hunter_jump, (90, 90))
    shoot_img = pygame.transform.scale(hunter_shoot, (90, 90))

    def __init__(self):
        self.image = self.walk_img

        self.jump_velocity = 0
        self.gravity = 1
        self.is_jumping = False
        self.is_shooting = False
        self.shoot_time = 0
        self.game_speed = GAME_SPEED

        self.rect = self.image.get_rect()
        self.rect.x = 50
        self.rect.y = BASE_GROUND_Y

    def jump(self):
        if not self.is_jumping:
            self.jump_velocity = -20
            self.is_jumping = True
            self.game_speed += 1

    def shoot(self):
        if not self.is_shooting:
            self.shoot_time = 15
            self.is_shooting = True

    def update(self):
        if self.is_jumping:
            self.rect.y += self.jump_velocity
            self.jump_velocity += self.gravity

            if self.jump_velocity < 0:
                self.image = self.jump_img
            else:
                self.image = self.walk_img
                self.game_speed = GAME_SPEED

            if self.rect.y >= BASE_GROUND_Y:
                self.rect.y = BASE_GROUND_Y
                self.is_jumping = False
                self.jump_velocity = 0
                self.image = self.walk_img

        if self.is_shooting:
            self.shoot_time -= 1

            if self.shoot_time > 0:
                self.game_speed = 1
                self.image = self.shoot_img
            else:
                self.shoot_time = 0
                self.game_speed = GAME_SPEED
                self.image = self.walk_img
                self.is_shooting = False

    def draw(self, display_surface):
        display_surface.blit(self.image, self.rect)


