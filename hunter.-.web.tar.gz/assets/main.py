import pygame
import sys
from random import randint
import asyncio

from elements.configs import (
    CAPTION,
    WINDOW_WIDTH,
    WINDOW_HEIGHT,
    GROUND_X,
    OBSTACLES,
    SHOOTABLE_OBJ,
)

pygame.init()


pygame.display.set_caption(CAPTION)

display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))


from elements.hunter import Hunter
from elements.obstacles import Bird, Wolf, Rock    


class Game:
    def __init__(self):
        self.running = True
        self.clock = pygame.time.Clock()
        self.hunter = Hunter()
        # self.sun = Sun()
        self.ground_img = pygame.image.load("images/path.png").convert_alpha()
        self.ground = pygame.transform.scale(self.ground_img, (3000, 500))
        self.ground_x = GROUND_X
        self.display_surface = display_surface


    def draw_game_over(self):
        game_over_font = pygame.font.SysFont('freesanbold.ttf', 70)
        game_over_txt = game_over_font.render('GAME OVER!', True, (112, 81, 71))
        game_over_rect = game_over_txt.get_rect()
        game_over_rect.center = (300, 200)
        display_surface.blit(game_over_txt, game_over_rect)
       
  


    def handle_restart(self):
        self.hunter = Hunter()
        # self.sun = Sun()
        self.ground_x = GROUND_X
        OBSTACLES.clear()

    def _run(self):

        asyncio.run(self.main())


    async def main(self):
    

        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.KEYDOWN:
                    if self.hunter.is_alive:
                        if event.key == pygame.K_SPACE:
                            self.hunter.jump()

                        if event.key == pygame.K_s:
                            self.hunter.shoot()
                    
                    if event.key == pygame.K_r:
                        self.handle_restart()

            if self.hunter.is_alive:
                self.ground_x -= self.hunter.game_speed

                if self.ground_x <= -2900:
                    self.ground_x = 0

                display_surface.blit(self.ground, (self.ground_x, 0))

                # self.sun.update(display_surface)

                if len(OBSTACLES) == 0:
                    random_number = randint(0, 10)

                    if random_number == 5:
                        OBSTACLES.append(Wolf())
                    elif random_number == 1:
                        OBSTACLES.append(Rock())
                    elif random_number == 2:
                        OBSTACLES.append(Bird())


                
                self.hunter.update()
                self.hunter.draw(display_surface)
                
                
                obstacle_list_cp = OBSTACLES[:]

                for obstacle in obstacle_list_cp:
                    obj_name = obstacle.__class__.__name__

                    obstacle.update(display_surface)

                    if getattr(obstacle, "was_shot", False):
                        continue

                    if self.hunter.rect.colliderect(obstacle.rect):
                        self.hunter.is_alive = False
                        break

                    if self.hunter.is_shooting and obj_name in SHOOTABLE_OBJ:
                        if obstacle.rect.x > self.hunter.rect.x:
                            obstacle.handle_element(True)
                            
            else:
                display_surface.blit(self.ground, (self.ground_x, 0))
                self.hunter.draw(display_surface)
                self.draw_game_over()

            pygame.display.update()
            self.clock.tick(60)
            await asyncio.sleep(0)


Game()._run()









    