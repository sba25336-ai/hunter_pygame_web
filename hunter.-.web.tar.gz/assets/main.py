import pygame
import sys
from random import randint

from elements.configs import (
    CAPTION,
    WINDOW_WIDTH,
    WINDOW_HEIGHT,
    GROUND_X,
    OBSTACLES,
    SHOOTABLE_OBJ,
)

pygame.init()


pygame.display.set_caption(CAPTION)

display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))


from elements._hunter import Hunter
from elements._obstacles import Bird, Sun, Wolf, Rock






clock = pygame.time.Clock()

hunter = Hunter()
sun = Sun()
ground = pygame.image.load("images/path.png").convert()

ground_x = GROUND_X


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                hunter.jump()

            if event.key == pygame.K_s:
                hunter.shoot()

    ground_x -= hunter.game_speed

    if ground_x <= -2900:
        ground_x = 0

    display_surface.blit(ground, (ground_x, 0))

    sun.update(display_surface)

    if len(OBSTACLES) == 0:
        random_number = randint(0, 10)

        if random_number == 5:
            OBSTACLES.append(Wolf())
        elif random_number == 1:
            OBSTACLES.append(Rock())
        elif random_number == 2:
            OBSTACLES.append(Bird())

    hunter.update()
    hunter.draw(display_surface)

    for obstacle in OBSTACLES[:]:
        obj_name = obstacle.__class__.__name__

        obstacle.update(display_surface)

        if getattr(obstacle, "was_shot", False):
            continue

        if hunter.rect.colliderect(obstacle.rect):
            print("Collision!!!!")
            break

        if hunter.is_shooting and obj_name in SHOOTABLE_OBJ:
            if obstacle.rect.x > hunter.rect.x:
                obstacle.handle_element(True)
                print(f"Hunter shot the {obj_name}")

    pygame.display.update()
    clock.tick(60)